angular.module('neptuneWeb').directive('proposal', function() {

	var directive = {};

    directive.restrict = 'E'; /* restrict this directive to elements */
    directive.templateUrl = "templates/proposals/proposalInfo.html";
    //directive.template = "My first directive: {{textToInsert}}";
    return directive;
    
});
