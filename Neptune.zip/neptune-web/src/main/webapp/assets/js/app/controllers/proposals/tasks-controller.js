angular.module('neptuneTasks', [ 'NeptuneProposalsAPI','datatables'])

.controller('TasksController', function(ProposalAPI) {
	var controller = this;
	var tasks = [];
	
	ProposalAPI.loadProposalTasks(function(data){
		controller.tasks = data.records;
	},function(error){
		MsgPop.open({
			Type : 'error',
			Content : 'Error al obtener el listado de tareas: ' + error
		});
	});
})

.controller('QualifyProposalController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.qualify = function(){
		
		controller.proposal.architecture = new Date();
		controller.proposal.statusCode = "clif";
		controller.proposal.status = "Calificada";
		controller.proposal.taskId = $routeParams.task;
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
	
})

.controller('AMReviewController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.review = function(){
		controller.proposal.statusCode = "amreview";
		controller.proposal.status = "Revisado por AM";
		controller.proposal.taskId = $routeParams.task;
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
	
})

.controller('GenerateArchitectureController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.generate = function(){
		controller.proposal.statusCode = "srvreview";
		controller.proposal.status = "En revision de Servicios";
		controller.proposal.taskId = $routeParams.task;
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
	
})

.controller('hatpackController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.generate = function(){
		controller.proposal.statusCode = "hpreview";
		controller.proposal.status = "HatPack revisado";
		controller.proposal.taskId = $routeParams.task;
		controller.proposal.services = new Date();
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
	
})

.controller('ServicesReviewController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.review = function(){
		controller.proposal.statusCode = "svreviwed";
		controller.proposal.status = "Arquitectura Revisada";
		controller.proposal.taskId = $routeParams.task;
		controller.proposal.services = new Date();
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
	
})

.controller('GenerateServicesController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.generate = function(){
		controller.proposal.statusCode = "generateservices";
		controller.proposal.status = "Servicios generados";
		controller.proposal.taskId = $routeParams.task;
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
})

.controller('TeamReviewController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.review = function(){
		controller.proposal.statusCode = "teamareview";
		controller.proposal.status = "Revisado por el team";
		controller.proposal.taskId = $routeParams.task;
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
})

.controller('ClientReviewController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.review = function(){
		controller.proposal.statusCode = "clientreviewd";
		controller.proposal.status = "Revisado por cliente";
		controller.proposal.taskId = $routeParams.task;
		controller.proposal.delivery = new Date();
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
})

.controller('ReleaseProposalController', function($routeParams, ProposalAPI) {
	var controller = this;
	var proposal = {};
	
	this.release = function(){
		controller.proposal.statusCode = "proposalend";
		controller.proposal.status = "Propuesta Finalizada";
		controller.proposal.taskId = $routeParams.task;
		controller.proposal.close = new Date();
		ProposalAPI.completeTask(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta calificada'
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al calificar la propuesta: ' + error
			});
		});
	}
});
