angular.module('neptuneWeb').config(function($routeProvider) {
	$routeProvider.when('/users', {
		templateUrl : 'templates/users/users.html',
		controller : 'UsersController',
		controllerAs : 'usersCtrl'
	}).when('/user-details/:userId', {
		templateUrl : 'templates/users/user-details.html',
		controller : 'UserDetailController',
		controllerAs : 'userDetailCtrl'
	}).when('/user-create', {
		templateUrl : 'templates/users/user-create.html',
		controller : 'UserCreateController',
		controllerAs : 'userCreateCtrl'
	}).when('/user-roles', {
		templateUrl : 'templates/users/user-roles.html',
		controller : 'UserRolesController',
		controllerAs : 'userRolesCtrl'
	}).when('/proposal-create', {
		templateUrl : 'templates/proposals/createProposal.html',
		controller : 'ProposalCreateController',
		controllerAs : 'proposalCreateCtrl'
	}).when('/proposals', {
		templateUrl : 'templates/proposals/proposals.html',
		controller : 'ProposalsController',
		controllerAs : 'proposalsCtrl'
	}).when('/tasks', {
		templateUrl : 'templates/proposals/tasks.html',
		controller : 'TasksController',
		controllerAs : 'tasksCtrl'
	}).when('/CalificarPropuesta/:task', {
		templateUrl : 'templates/proposals/qualifyProposal.html',
		controller : 'QualifyProposalController',
		controllerAs : 'qpCtrl'
	}).when('/RevisionAM/:task', {
		templateUrl : 'templates/proposals/amReview.html',
		controller : 'AMReviewController',
		controllerAs : 'amrCtrl'
	}).when('/GenerarArquitectura/:task', {
		templateUrl : 'templates/proposals/generateArchitecture.html',
		controller : 'GenerateArchitectureController',
		controllerAs : 'gaCtrl'
	}).when('/PrepararHatPack/:task', {
		templateUrl : 'templates/proposals/hatPack.html',
		controller : 'hatpackController',
		controllerAs : 'hpCtrl'
	}).when('/RecepcionServicios/:task', {
		templateUrl : 'templates/proposals/servicesReview.html',
		controller : 'ServicesReviewController',
		controllerAs : 'srCtrl'
	}).when('/GenerarServicios/:task', {
		templateUrl : 'templates/proposals/generateServices.html',
		controller : 'GenerateServicesController',
		controllerAs : 'gsCtrl'
	}).when('/RevisionTeam/:task', {
		templateUrl : 'templates/proposals/teamReview.html',
		controller : 'TeamReviewController',
		controllerAs : 'trCtrl'
	}).when('/EntregaCliente/:task', {
		templateUrl : 'templates/proposals/clientReview.html',
		controller : 'ClientReviewController',
		controllerAs : 'crCtrl'
	}).when('/LiberarPropuesta/:task', {
		templateUrl : 'templates/proposals/releaseProposal.html',
		controller : 'ReleaseProposalController',
		controllerAs : 'rpCtrl'
	}).when('/uiElements', {
		templateUrl : 'templates/ui/uiElements.html',
		controller : 'uiElementsController',
		controllerAs : 'uiCtrl'
	})
});
