angular.module('NeptuneUserAdminAPI', ['AjaxService'])

.factory('UserAdminAPI', function(Ajax) {
	var instance = {};

	instance.restURL = 'http://localhost:8080/neptune/rest/';

	instance.sha256 = CryptoJS.algo.SHA256.create();

	instance.createUser = function(user, success, error) {
		var rest = instance.restURL + 'users/create';
		try {
			var hash = CryptoJS.SHA256(user.password);
			var base64 = hash.toString(CryptoJS.enc.Base64);
			user.password = base64;
			Ajax.post(rest , roles, sucess, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.getUserInfo = function(userId, success, error){
		var rest = instance.restURL +  'info/'+userId;
		Ajax.get(rest,success, error);
	}
	
	instance.getRoles = function(success, error){
		var rest =  instance.restURL +  'roles/list';
		Ajax.get(rest, success);
	}

	instance.listUsers = function(success, error){
		var rest = instance.restURL + 'users/list';
		Ajax.get(rest, success, error);
	}
	
	return instance;
});