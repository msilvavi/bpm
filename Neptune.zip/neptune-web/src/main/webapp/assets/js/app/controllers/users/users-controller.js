angular.module('neptuneAdminUsers', [ 'NeptuneUserAdminAPI','datatables'])

.controller('UsersController', function(UserAdminAPI, DTOptionsBuilder, DTColumnDefBuilder) {
	var controller = this;
	var users = [];
	controller.dtOptions = DTOptionsBuilder.newOptions().withPaginationType('full_numbers').withDisplayLength(2);
	controller.dtColumnDefs = [
                       DTColumnDefBuilder.newColumnDef(0),
                       DTColumnDefBuilder.newColumnDef(1).notVisible(),
                       DTColumnDefBuilder.newColumnDef(2).notSortable(),
                       DTColumnDefBuilder.newColumnDef(3)
                   ];
	UserAdminAPI.listUsers(function(data){
		controller.users = data.records;
	}, function(error){
		MsgPop.open({
			Type : 'error',
			Content : 'Error al obtener la lista de usuarios: ' + error
		});
	});

})

.controller('UserDetailController', function($routeParams, UserAdminAPI) {
	var controller = this;
	var user;
	UserAdminAPI.getUserInfo($routeParams.userId, function(data) {
		controller.user = data;
	}, function(error) {
		MsgPop.open({
				Type : 'error',
				Content : 'Error al obtener datos del usuario: ' + error
			});
	});
})

.controller('UserCreateController', function($routeParams,UserAdminAPI) {
	var controller = this;
	var user = {};
	var roles = [];	
	var selectedRoles = [];
	var assignedRoles = [];
	
	UserAdminAPI.getRoles(function(data){
		controller.roles = data;
	}, function(error){
		MsgPop.open({
			Type : 'error',
			Content : 'Error al obtener los roles disponibles: ' + error
		});
	});
	
	this.createUser = function() {
		UserAdminAPI.createUser(controller.user,function(data){
			controller.user = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Usuario creado correctamente '
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al crear el usuario: ' + error
			});
		});
	}
})
.controller('UserRolesController', function($routeParams, UserAdminAPI) {
	var controller = this;
	var user;
	var roles;
		
	UserAdminAPI.getRoles(function(data) {
		controller.roles = data;
	}, function(error) {
		MsgPop.open({
				Type : 'error',
				Content : 'Error al obtener los roles disponibles: ' + error
			});
	});
	
	this.findUser = function(){
		UserAdminAPI.getUserInfo(controller.userId, function(data) {
			controller.user = data;
		}, function(error) {
			MsgPop.open({
					Type : 'error',
					Content : 'Error al obtener datos del usuario: ' + error
				});
		});
	}
	
	
	this.assignRoles = function() {
		
	}
});
