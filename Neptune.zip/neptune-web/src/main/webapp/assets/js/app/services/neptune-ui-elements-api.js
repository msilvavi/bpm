angular.module('UIElementsAPI', ['AjaxService'])

.factory('UIAPI', function(Ajax) {
	var instance = {};

	instance.restURL = 'http://localhost:8080/neptune/rest/';
	
	instance.uploadFileToUrl = function(selectedFile, fileName ,success, error){
		var rest = instance.restURL + 'uploads/fileupload';
        var fd = new FormData();
        fd.append('selectedFile', selectedFile);
        fd.append('fileName', fileName)
        try {
        	Ajax.uploadFile(rest,fd,success,error);
        } catch (exception) {
			error(exception);
		}
    }
	
	return instance;
});