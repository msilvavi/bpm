angular.module('neptuneProposals', [ 'NeptuneProposalsAPI','NeptuneUserAdminAPI','datatables'])

.controller('ProposalsController', function() {
	var controller = this;
	var users = [];
})

.controller('ProposalInfoController', function(ProposalAPI, $routeParams) {
	var controller = this;
	var proposal = {};
	
	ProposalAPI.loadProposalVariables($routeParams.task,function(data){
		controller.proposal = data;
	},function(error){
		MsgPop.open({
			Type : 'error',
			Content : 'Error al obtener el listado de tareas: ' + error
		});
	});
	
})

.controller('ProposalCreateController', function(ProposalAPI, UserAdminAPI) {
	var controller = this;
	var proposal;
	var users = [];
	var products = [];
	var selectedProducts = [];
	
	ProposalAPI.loadProducts(function(data){
		controller.products = data.records;
	},function(error){
		MsgPop.open({
			Type : 'error',
			Content : 'Error al obtener el listado de productos registrados: ' + error
		});
	});
	
	UserAdminAPI.listUsers(function(data){
		controller.users = data.records;
	},function(error){
		MsgPop.open({
			Type : 'error',
			Content : 'Error al obtener el listado de usuarios registrados: ' + error
		});
	});
	
	this.createProposal = function(){
		controller.proposal.creation = new Date();
		ProposalAPI.createProposal(controller.proposal, function(data){
			controller.proposal = {};
			MsgPop.open({
				Type : 'success',
				Content : 'Propuesta creada correctamente '
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al crear la propuesta: ' + error
			});
		});
	}
});
