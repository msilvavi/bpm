angular.module('AjaxService', [])

.factory('Ajax', function($http) {
	var instance = {};
         
     $http.defaults.useXDomain = true;

     instance.uploadFile = function(serviceUrl, fd, success, error){
    	 $http.post(serviceUrl, fd, {
    		 headers: {
                 'Content-Type': undefined
               },
               transformRequest: angular.identity
         }).success(function(response) {
  			success(response);
  		}).error(function(response) {
  			error(response);
  		});
 	}
     
     
	instance.post = function(serviceUrl, request, success, error){
		$http({
            url: serviceUrl,
            method: "POST",
            data: request,
            withCredentials: true
        }).success(function(response) {
			success(response);
		}).error(function(response) {
			error(response);
		});
	}
	
    instance.get = function(serviceUrl, success, error){
    	$http({
            url: serviceUrl,
            method: "GET",
            withCredentials: true
        }).success(function(response) {
			success(response);
		}).error(function(response) {
			error(response);
		});
	}
	
	instance.put = function(url, request, success, error){
		$http({
            url: serviceUrl,
            method: "PUT",
            data: request,
            withCredentials: true
        }).success(function(response) {
			success(response);
		}).error(function(response) {
			error(response);
		});
	}
	
	instance.delete = function(url, success, error){
		$http({
            url: serviceUrl,
            method: "DELETE",
            withCredentials: true
        }).success(function(response) {
			success(response);
		}).error(function(response) {
			error(response);
		});
	}

	return instance;
});