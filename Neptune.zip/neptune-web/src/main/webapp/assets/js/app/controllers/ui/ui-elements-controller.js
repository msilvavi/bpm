angular.module('uiElementsModule', [ 'UIElementsAPI','datatables'])

.controller('uiElementsController', function(UIAPI) {
	var controller = this;
	var selectedFile;
	var fileName;
	
	this.setFile = function(file){
		controller.fileName = file;
	}
	
	this.uploadFile = function(){

        UIAPI.uploadFileToUrl(selectedFile, fileName, function(data){
			MsgPop.open({
				Type : 'success',
				Content : 'Archivo enviado '
			});
		},function(error){
			MsgPop.open({
				Type : 'error',
				Content : 'Error al enviar archivo: ' + error
			});
		});
    };
	
});
