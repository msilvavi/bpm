(function() {
	var app = angular.module('neptuneWebSidebar', []);
	
	app.controller('SidebarController',function(){
		var toggle = false;
		var sidebar;
		
		function sidbarInit(){
			if ($(window).width() < 768) {
                sidebar.addClass('collapse')
            } else {
                sidebar.removeClass('collapse')
            }
		}
	})
	
})();