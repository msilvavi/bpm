angular.module('neptuneWeb', [ 'ngRoute','neptuneTasks','neptuneWebSidebar','neptuneProposals','neptuneAdminUsers','datatables','uiElementsModule' ])

.controller('MainController', function($scope) {
	

});
