angular.module('NeptuneProposalsAPI', ['AjaxService'])

.factory('ProposalAPI', function(Ajax) {
	var instance = {};

	instance.restURL = 'http://localhost:8080/neptune/rest/';

	instance.createProposal = function(proposal, success, error) {
		var rest = instance.restURL + 'proposals/create';
		try {
			Ajax.post(rest, proposal, success, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.loadProducts = function(success, error){
		var rest = instance.restURL + 'products/list';
		try {
			Ajax.get(rest, success, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.loadTasks = function(success, error){
		var rest = instance.restURL + 'proposals/tasks';
		try {
			Ajax.get(rest, success, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.loadProposalTasks = function(success, error){
		var rest = instance.restURL + 'proposals/proposals';
		try {
			Ajax.get(rest, success, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.completeTask = function(proposal, success, error){
		var rest = instance.restURL + 'proposals/complete';
		try {
			Ajax.post(rest, proposal, success, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.loadProposalInfo = function(taskId, success, error){
		var rest = instance.restURL + 'proposals/proposal-info/' + taskId;
		try {
			Ajax.get(rest, success, error);
		} catch (exception) {
			error(exception);
		}
	}
	
	instance.loadProposalVariables = function(taskId, success, error){
		var rest = instance.restURL + 'proposals/proposal-variables/' + taskId;
		try {
			Ajax.get(rest, success, error);
		} catch (exception) {
			error(exception);
		}
	}

	return instance;
});