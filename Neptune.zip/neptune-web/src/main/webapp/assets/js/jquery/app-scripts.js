/*------------------------------------------------------
    Author : www.webthemez.com
    License: Commons Attribution 3.0
    http://creativecommons.org/licenses/by/3.0/
---------------------------------------------------------  */

(function ($) {
    "use strict";
    
    $.getScript('assets/js/jquery/users-script.js', function() {
       
    });
    
    var restUrl = "http://localhost:8080/needit-server/rest/";
    var loggedName;
    var activeMenu;
    
    var mainApp = {

        initFunction: function () {
            /*MENU 
            ------------------------------------*/
            $('#main-menu').metisMenu();
			
            $(window).bind("load resize", function () {
                if ($(this).width() < 768) {
                    $('div.sidebar-collapse').addClass('collapse')
                } else {
                    $('div.sidebar-collapse').removeClass('collapse')
                }
            });
        },

        initialization: function () {
            mainApp.initFunction();
        }

    }
    
    // Initializing ///
    $(document).ready(function () {
        mainApp.initFunction();
    });
    
    $(window).load(function($) {
//	    loadDashboard();
	});
    
    //Load Dashboard
//    $('#dashboardMenu').click(function(e){
//    	e.preventDefault();
//    	$("#page-wrapper").load("templates/intro.html",function() {
//			setActiveMenu($('#dashboardMenu'));
//		});
//    });
    
    //Load Users Page
//    $('#usersMenu').click(function(e){
//    	e.preventDefault();
//    	$("#page-wrapper").load("templates/users/users.html",function() {
//    		setActiveMenu($('#usersMenu'));
//    		drawUsersTable(restUrl, $('#tblusers'));
//		});
//    });
    
  //Load init data from server
	var loadDashboard = function(){ 
		var requestUrl = restUrl+"user/login/info";
		ajaxGetRequest(requestUrl, function(data) {
			loggedName=data.name;
		})
	}
	
//###### Menu Functions #########
	
	//Set active menu
	var setActiveMenu = function(element){
		if(activeMenu!=null){
			activeMenu.removeClass('active-menu');
		}
		element.addClass('active-menu');
		activeMenu = element;
	}
	
	
//###### Ajax Request Functions #########
		
	//Invoke GET Services
	var ajaxGetRequest = function(requestUrl, success){ 
		$.ajax({
		    url: requestUrl,
		    type: "GET",
		    contentType: "application/json",
		    success: function (data) {
		    	success(data);
		    },
		    error: function (jqXHR, textStatus, errorThrown) {
		    	MsgPop.open({
		          	  Type:  "error",
		          	  Content:errorThrown});
		    }
		});
	}
		
	//Invoke POST Services
	var ajaxPostRequest = function(requestUrl, json, success){ 
		$.ajax({
		    url: requestUrl,
		    type: 'POST',
		    contentType: "application/json",
		    data: json,
		    dataType: "json",
		    success: function (data) {
		    	success(data);
		    },
		    error: function (jqXHR, textStatus, errorThrown) {
		    	MsgPop.open({
		          	  Type:  "error",
		          	  Content:errorThrown});
		    }
		});
	}

}(jQuery));
