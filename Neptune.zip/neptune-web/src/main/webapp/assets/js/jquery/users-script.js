var drawUsersTable = function(restUrl, table) {
	var requestUrl = restUrl + 'user/list';
	table.dynatable({
		  table: {
		    bodyRowSelector: 'tr'
		  },
		  dataset: {
		    ajax: true,
		    ajaxUrl: requestUrl,
		    ajaxOnLoad: true,
		    records: []
		  },
		  writers: {
			_rowWriter: drawUsersTableRow
		  }
	});
}

var drawUsersTableRow = function(rowIndex, record, columns, cellWriter) {
	var tr = "<tr class='gradeA' />"+
		 "<td><a href='"+record.userId+"'>" + record.userId + "</a></td>"+
		 "<td>" + record.name + "</td>"+
		 "<td>" + record.surname + "</td>";
	return tr;
}

var createUser = function(user, restUrl){
	
}
