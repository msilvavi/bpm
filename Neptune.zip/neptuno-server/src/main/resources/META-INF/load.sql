INSERT INTO roles(role_id,role_name,role_description) VALUES (nextval('roles_sequence'),'LOGGED','Logged users');
INSERT INTO users(user_id, name, surname, lastname, password, username, active) VALUES (nextval('users_sequence'), 'Isaac', 'Galvan', 'Lañado', '08r3o+6YdBD4upKA1Ym7TNlIwyT7px/lt9BAx+z2YFA=', 'igalvan',true);
INSERT INTO user_roles VALUES (currval('users_sequence'),currval('roles_sequence'));
INSERT INTO roles(role_id,role_name,role_description) VALUES (nextval('roles_sequence'),'ADMIN','Admin users');
INSERT INTO user_roles VALUES (currval('users_sequence'),currval('roles_sequence'));