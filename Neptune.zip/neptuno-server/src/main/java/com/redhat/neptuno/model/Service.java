package com.redhat.neptuno.model;

public class Service {

}
