package com.redhat.neptuno.services;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.HEAD;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.redhat.neptuno.controllers.RoleController;
import com.redhat.neptuno.model.Role;
import com.redhat.neptuno.utils.Roles;

@RolesAllowed(Roles.USERS_ADMIN)
@Path("/roles")
public class RoleRest {

	private static final Logger log = Logger.getLogger(RoleRest.class);

	@Inject
	RoleController roleController;

	@Context
	ServletContext ctx;
	@Context
	private HttpServletResponse response;
	@Context
	private HttpServletRequest request;

	@GET
	@Path("/list")
	@RolesAllowed("ADMIN")
	@Produces(MediaType.APPLICATION_JSON)
	@HEAD()
	public List<Role> listRoles() {
		log.info("Aquiring role list");
		List<Role> roles = roleController.getRoleList();
		return roles;
	}


}
