package com.redhat.neptuno.utils;

import java.io.IOException;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.ext.Provider;

import org.apache.log4j.Logger;
import org.jboss.resteasy.annotations.interception.ServerInterceptor;
import org.jboss.resteasy.spi.interception.MessageBodyWriterContext;
import org.jboss.resteasy.spi.interception.MessageBodyWriterInterceptor;

@Provider
@ServerInterceptor
public class CorsHeaderDecorator implements MessageBodyWriterInterceptor {

	private static final Logger log = Logger.getLogger(CorsHeaderDecorator.class);
	
    public void write(MessageBodyWriterContext context) throws IOException, WebApplicationException
    {
       context.getHeaders().add("Access-Control-Allow-Origin", "http://localhost:8080");
       context.getHeaders().add("Access-Control-Allow-Headers","origin, content-type, accept, authorization");
       context.getHeaders().add("Access-Control-Allow-Credentials", "true");
       context.getHeaders().add("Access-Control-Allow-Methods","GET, POST, PUT, DELETE, OPTIONS, HEAD");
       context.proceed();
    }
}