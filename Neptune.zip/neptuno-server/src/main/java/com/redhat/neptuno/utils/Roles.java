package com.redhat.neptuno.utils;

public class Roles{
    public static final String USERS_ADMIN = "ADMIN";
    public static final String LOGGED = "LOGGED";
}