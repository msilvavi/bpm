package com.redhat.neptuno.controllers;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import com.redhat.neptuno.model.Role;

public class RoleController {

private static final Logger log = Logger.getLogger(RoleController.class);
	
	@Inject
	UserTransaction tm;
	
	@PersistenceContext(unitName = "needit-persistence-unit")
	EntityManager em;
	
	public Role findRoleById(Long id){
		Role role = null;
		Query q = em.createNamedQuery("Role.findRoleByRoleId", Role.class);
		q.setParameter("roleId", id); 
		try {
			Object result = q.getSingleResult();
			if (result != null) {
				role = (Role) result;
			}
		} catch (NoResultException e) {
			log.warn("No result found", e);
		}
		return role;
	}
	
	@SuppressWarnings("unchecked")
	public List<Role> getRoleList(){
		List<Role> roles = null;
		Query q = em.createNamedQuery("Role.findRoles", Role.class);
		roles = q.getResultList();
		return roles;
	}
	
}
