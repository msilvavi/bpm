package mx.com.simtech.needit.tests.controllers;


//@RunWith(Arquillian.class)
public class UserControllerTest {

//	@Deployment
//    public static Archive<?> createTestArchive() {
// 
//        return ShrinkWrap.create(WebArchive.class, "needit-server.war")
//                .addPackage(UserController.class.getPackage())
//                .addPackage(ControllerException.class.getPackage())
//                .addPackage(User.class.getPackage())
//                .addPackage(ObjectMapperResolver.class.getPackage())
//                .addPackage(UserRest.class.getPackage())
//                .addAsResource("META-INF/persistence.xml")
//                .addAsResource("META-INF/load.sql")
//                .addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml")
//                .addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml")
//                // Deploy our test datasource
//                ;
// 
//    }
//	
//	@Inject
//	UserController userController;
//	
//	@Test
//	public void test() {
//		User user = userController.getUserByUsername("igalvan");
//		Assert.assertEquals(user.getName(), "Isaac");
//	}

}
