package com.redhat.systems.neptune.model.users;

public class Service {

}
