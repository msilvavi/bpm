package com.redhat.systems.neptune.util;

public class Roles{
    public static final String USERS_ADMIN = "admin";
    public static final String REST_ALL = "rest-all";
}